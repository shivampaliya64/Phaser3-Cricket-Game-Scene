var v1;
var GameScene1 = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize:
    function GameScene1 ()
    {
        Phaser.Scene.call(this, { key: 'GameScene1' });
    },

    preload: function ()
    {
        this.load.video('v1', 'assets/v1.mp4', 'loadeddata', false, false);
    },
    create: function ()
    {   
        var txt1 = this.add.text(400,500, 'start');
        txt1.setInteractive().on('pointerdown', function() {
            this.scene.scene.start('GameScene2');
        });
        v1=this.add.video(400,300,'v1');
        v1.play();
    }
});
//create a scene with class
var ball,ipl;
var GameScene2 = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize:
    function GameScene ()
    {
        Phaser.Scene.call(this, { key: 'GameScene2' });
    },
    preload: function (){
        this.load.image('s1','assets/TurboCricket.jpg');
        this.load.image('ball','assets/ball.png');
        this.load.audio("ipl",["assets/ipl.ogg","assets/ipl.mp3"]);
    },
    create: function ()
    {   
        let bg= this.add.sprite(400,300,'s1');
        ball=this.add.sprite(600,350,'ball');
        ball.displayWidth=25;
        ball.displayHeight=25;
        cursors = this.input.keyboard.createCursorKeys();  
        let soundSample=this.sound.add('ipl');
        soundSample.play();
        if(ball.y<=0){
            this.scene.scene.start('GameScene3');   
        }
    },
    update:function(){
        var flag=0;
        if(ball.x>340 && flag==0)
            ball.x-=1; 
        else{
            flag=1;
            ball.y-=1;
        }
       
        
        
}

});
var GameScene3 = new Phaser.Class({
    Extends: Phaser.Scene,
    initialize:
    function GameScene ()
    {
        Phaser.Scene.call(this, { key: 'GameScene3' });
    },
    preload: function (){
        
    },

    create: function ()
    {   
        
    },

    update:function(){
        
    }

});

//settings required to configure the game
var config = {
    type: Phaser.AUTO,   
    width: 800,
    height:  700,
    x:0,
    y:0,
    physics: {
        default: 'arcade',
        arcade:{debug:true}
    },
    backgroundColor: 0x27ae60,
    scale: {
        autoCenter: Phaser.Scale.CENTER_BOTH
    },
    //set scenes
    scene:[GameScene1,GameScene2,GameScene3]
    
};
var game = new Phaser.Game(config);